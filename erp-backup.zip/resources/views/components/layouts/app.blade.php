<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="scroll-smooth">
    <head>
        <meta charset="utf-8">

        <meta name="application-name" content="{{ config('app.name') }}">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>{{ config('app.name') }}</title>

        {{-- Search Engine Indexing Control --}}
        @php
            $generalSettings = app(\App\Settings\GeneralSettings::class);
            $allowIndexing = $generalSettings->search_engine_indexing ?? false;
        @endphp

        @if(!$allowIndexing)
            <meta name="robots" content="noindex, nofollow">
        @endif

        <style>
            [x-cloak] {
                display: none !important;
            }
        </style>

        @filamentStyles
        @vite('resources/css/app.css')
    </head>

    <body class="antialiased">
        <div
    x-data="pageTransition"
    x-init="init"
    x-show="show"
    x-transition:enter="transition ease-out duration-300"
    x-transition:enter-start="opacity-0 translate-y-2"
    x-transition:enter-end="opacity-100 translate-y-0"
    class="min-h-screen"

      x-data="{ open: true }"
  x-show="open"
  x-transition:enter="transition ease-out duration-300"
  x-transition:enter-start="opacity-0 scale-95"
  x-transition:enter-end="opacity-100 scale-100"
>
    {{ $slot }}
</div>

        <livewire:notification-bell />
        @livewire('database-notifications')

        @filamentScripts
        @vite('resources/js/app.js')
    </body>
</html>