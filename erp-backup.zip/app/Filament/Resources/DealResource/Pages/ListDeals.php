<?php

namespace App\Filament\Resources\DealResource\Pages;

use App\Filament\Resources\DealResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use EightyNine\FilamentExcelImport\Actions\ImportAction;
use EightyNine\FilamentExcelImport\Actions\ImportField;
use EightyNine\ExcelImport\ExcelImportAction;
use Filament\Forms\Components\Actions\Action;
use App\Exports\SampleExport;


class ListDeals extends ListRecords
{
    protected static string $resource = DealResource::class;

    protected function getHeaderActions(): array
{
    return [

        Actions\CreateAction::make(),
        \EightyNine\ExcelImport\ExcelImportAction::make()
            ->label('Import Excel')
            ->color('info')
            ->sampleExcel(
                sampleData: [
                    [
                        'nama_pic' => 'John Doe',
                        'product_id' => 1,
                        'nama_perusahaan' => 'PT. Contoh Sukses',
                        'email' => 'john@contoh.com',
                        'telephone' => '08123456789',
                        'source' => 'Website',
                        'alamat' => 'Jl. Contoh No. 123, Jakarta',
                        'NPWP' => '123456789012345',
                        'notes' => 'Pelanggan potensial',
                        'status' => 'Negosiasi'
                    ],
                    [
                        'nama_pic' => 'Jane Doe',
                        'product_id' => 2,
                        'nama_perusahaan' => 'CV. Maju Jaya',
                        'email' => 'jane@majujaya.com',
                        'telephone' => '08987654321',
                        'source' => 'Referral',
                        'alamat' => 'Jl. Sukses No. 456, Bandung',
                        'NPWP' => null,
                        'notes' => 'Follow up dalam 2 minggu',
                        'status' => 'Menunggu Pembayaran'
                    ],
                ],
                fileName: 'sample.xlsx',
                exportClass: SampleExport::class,
                sampleButtonLabel: 'Download Sample',
                customiseActionUsing: fn(Action $action) => $action->color('info')
                    ->icon('heroicon-m-clipboard')
                    ->requiresConfirmation(),
            ),
    ];
}
}