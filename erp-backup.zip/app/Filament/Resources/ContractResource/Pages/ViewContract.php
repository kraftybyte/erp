<?php

namespace App\Filament\Resources\ContractResource\Pages;

use App\Filament\Resources\ContractResource;
use App\Models\Contract;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Contracts\View\View;

class ViewContract extends ViewRecord
{
    protected static string $resource = ContractResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\EditAction::make(),
        ];
    }

    public function downloadContract(): StreamedResponse
    {
        $contract = $this->record;

        if ($contract->type === 'file' && $contract->file_path) {
            return response()->download(
                storage_path('app/public/' . $contract->file_path),
                'contract-' . $contract->id . '.' . pathinfo($contract->file_path, PATHINFO_EXTENSION)
            );
        }

        abort(404, 'File not found.');
    }
}