<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ContractResource\Pages;
use App\Helpers\ColorHelper;
use App\Models\Contract;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Select;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;


class ContractResource extends Resource
{
    protected static ?string $model = Contract::class;
    protected static ?string $navigationIcon = 'heroicon-o-document-text';
    protected static ?string $navigationLabel = 'Contracts';
    protected static ?int $navigationSort = 8;

    public static function getNavigationGroup(): ?string
    {
        return __('CRM');
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Client Information')
                    ->schema([
                        Select::make('deal_id')
                            ->label('Client / Deal')
                            ->relationship('deal', 'nama_perusahaan')
                            ->searchable()
                            ->preload()
                            ->required(),
                    ]),

                Forms\Components\Section::make('Contract Details')
                    ->schema([
                        Select::make('type')
                            ->label('Contract Type')
                            ->options([
                                'editor' => 'Rich Text Editor',
                                'file' => 'File Upload',
                            ])
                            ->required()
                            ->live(),

                        MarkdownEditor::make('content')
                            ->label('Contract Content')
                            ->visible(fn (callable $get) => $get('type') === 'editor')
                            ->columnSpanFull(),

                        FileUpload::make('file_path')
                            ->label('Contract File')
                            ->visible(fn (callable $get) => $get('type') === 'file')
                            ->directory('contracts/' . now()->format('Y-m'))
                            ->preserveFilenames()
                            ->downloadable()
                            ->openable()
                            ->nullable()
                            ->columnSpanFull()
                            ->acceptedFileTypes([
                                'application/pdf',
                                'application/msword',
                                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            ]),
                    ]),

                Forms\Components\Section::make('Validity Period')
                    ->schema([
                        DatePicker::make('effective_date')
                            ->label('Effective Date')
                            ->required()
                            ->closeOnDateSelection(),

                        DatePicker::make('expiration_date')
                            ->label('Expiration Date')
                            ->required()
                            ->closeOnDateSelection()
                            ->minDate(fn (callable $get) => $get('effective_date')),
                    ])->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn(Builder $query) => $query->with(['deal']))
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable()
                    ->weight('bold'),

                TextColumn::make('deal.nama_perusahaan')
                    ->searchable()
                    ->label('Client')
                    ->limit(30)
                    ->tooltip(fn ($record) => $record->deal?->nama_perusahaan),

                BadgeColumn::make('type')
                    ->label('Type')
                    ->color(fn ($record) => ColorHelper::contractType($record->type)),

                TextColumn::make('effective_date')
                    ->date('d/m/Y')
                    ->label('Effective'),

                TextColumn::make('expiration_date')
                    ->date('d/m/Y')
                    ->label('Expiration'),

                TextColumn::make('created_at')
                    ->dateTime('d/m/Y H:i')
                    ->label('Created')
                    ->sortable(),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListContracts::route('/'),
            'view' => Pages\ViewContract::route('/{record}'),
            'create' => Pages\CreateContract::route('/create'),
            'edit' => Pages\EditContract::route('/{record}/edit'),
        ];
    }
}