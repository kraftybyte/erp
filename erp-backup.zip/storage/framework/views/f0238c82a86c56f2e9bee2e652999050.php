<?php
    $eventClickEnabled = $this->isEventClickEnabled() ? 'true' : 'false';
    $eventDragEnabled = $this->isEventDragEnabled() ? 'true' : 'false';
    $eventResizeEnabled = $this->isEventResizeEnabled() ? 'true' : 'false';
    $dateClickEnabled = $this->isDateClickEnabled() ? 'true' : 'false';
    $dateSelectEnabled = $this->isDateSelectEnabled() ? 'true' : 'false';

    $settings = app(\App\Settings\GeneralSettings::class);
    $legendCategories = $settings->event_categories ?? [];
?>

<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .ec { --ec-border-color: rgb(var(--gray-200)); }
        .ec .ec-event {
            border-radius: 8px;
            font-weight: 500;
            padding: 4px 6px;
            font-size: 12px;
            border: none;
            transition: 0.15s ease;
        }
        .ec .ec-event:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 6px rgba(0,0,0,0.15);
        }
        .dark .ec .ec-event { color: #ffffff; }
        .ec .ec-toolbar { gap: 12px; }
        .ec .ec-toolbar .ec-button.ec-today {
            border-radius: 100px !important;
            border: 2px solid #e5e7eb !important;
            background: #f9fafb !important;
            color: #374151 !important;
        }
        .ec .ec-toolbar .ec-button.ec-prev,
        .ec .ec-toolbar .ec-button.ec-next {
            width: 42px !important;
            height: 42px !important;
            padding: 0 !important;
            border-radius: 9999px !important;
            border: 1px solid #e5e7eb !important;
            background: #f9fafb !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }
        .ec .ec-toolbar .ec-button.ec-prev { margin-right: 8px; }
        .ec .ec-toolbar .ec-button:hover {
            transform: translateY(-1px);
            transition: 0.15s ease;
        }
        .dark .ec .ec-toolbar .ec-button { background-color: rgba(255,255,255,0.05); }
    </style>

    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['headerActions' => $this->getCachedHeaderActions(),'footerActions' => $this->getCachedFooterActions()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header-actions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($this->getCachedHeaderActions()),'footer-actions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($this->getCachedFooterActions())]); ?>
         <?php $__env->slot('heading', null, []); ?> <?php echo e($this->getHeading()); ?> <?php $__env->endSlot(); ?>

        <div
            wire:ignore
            x-ignore
            ax-load
            ax-load-src="<?php echo e(\Filament\Support\Facades\FilamentAsset::getAlpineComponentSrc('calendar-widget', 'guava/calendar')); ?>"
            x-data="calendarWidget({
                view: '<?php echo e($this->getCalendarView()); ?>',
                locale: '<?php echo e($this->getLocale()); ?>',
                firstDay: <?php echo e($this->getFirstDay()); ?>,
                eventClickEnabled: <?php echo e($eventClickEnabled); ?>,
                eventDragEnabled: <?php echo e($eventDragEnabled); ?>,
                eventResizeEnabled: <?php echo e($eventResizeEnabled); ?>,
                dateClickEnabled: <?php echo e($dateClickEnabled); ?>,
                dateSelectEnabled: <?php echo e($dateSelectEnabled); ?>,
                dayHeaderFormat: null,
                slotLabelFormat: null,
            })"
        >
            <div id="calendar"></div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($legendCategories)): ?>
            <div class="mt-6">
                <div class="text-sm font-semibold mb-3">Keterangan Warna Agenda</div>
                <div class="flex flex-wrap gap-4">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $legendCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center gap-2 text-sm">
                            <div class="w-4 h-4 rounded-full" style="background-color: <?php echo e($cat['color'] ?? '#888'); ?>"></div>
                            <span><?php echo e($cat['label'] ?? 'Agenda'); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal5ff0e703a07de8ebda296413721dea82 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ff0e703a07de8ebda296413721dea82 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'guava-calendar::components.context-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guava-calendar::context-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ff0e703a07de8ebda296413721dea82)): ?>
<?php $attributes = $__attributesOriginal5ff0e703a07de8ebda296413721dea82; ?>
<?php unset($__attributesOriginal5ff0e703a07de8ebda296413721dea82); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ff0e703a07de8ebda296413721dea82)): ?>
<?php $component = $__componentOriginal5ff0e703a07de8ebda296413721dea82; ?>
<?php unset($__componentOriginal5ff0e703a07de8ebda296413721dea82); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-actions::components.modals','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-actions::modals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $attributes = $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $component = $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?><?php /**PATH /Users/macbook/Documents/ERP/App/resources/views/vendor/guava-calendar/widgets/calendar.blade.php ENDPATH**/ ?>