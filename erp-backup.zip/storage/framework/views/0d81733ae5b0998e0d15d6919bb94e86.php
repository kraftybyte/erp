<?php if (isset($component)) { $__componentOriginal9b945b32438afb742355861768089b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b945b32438afb742355861768089b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.card','data' => ['class' => 'relative isolate overflow-hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'relative isolate overflow-hidden']); ?>

    
    <div class="pointer-events-none absolute top-0 right-0 h-40 w-40 rounded-full bg-primary-500/10 blur-2xl"></div>

    <?php
        $text = $report->analysis ?? '';

        preg_match('/STATUS:(.*)/i', $text, $statusMatch);
        preg_match('/TREN UTAMA:(.*)/i', $text, $trendMatch);
        preg_match('/RISIKO TERBESAR:(.*)/i', $text, $riskMatch);
        preg_match('/AKSI 7 HARI:(.*)/i', $text, $actionMatch);
        preg_match('/PELUANG STRATEGIS:(.*)/i', $text, $opportunityMatch);

        $status = trim($statusMatch[1] ?? 'MENUNGGU DATA');
        $trend = trim($trendMatch[1] ?? '-');
        $risk = trim($riskMatch[1] ?? '-');
        $action = trim($actionMatch[1] ?? '-');
        $opportunity = trim($opportunityMatch[1] ?? '-');

        $statusLower = strtolower($status);

        if (str_contains($statusLower, 'kritis')) {
            $badge = 'bg-red-100 text-red-700 ring-red-300';
            $icon = '🚨';
        } elseif (str_contains($statusLower, 'waspada')) {
            $badge = 'bg-yellow-100 text-yellow-700 ring-yellow-300';
            $icon = '⚠️';
        } else {
            $badge = 'bg-green-100 text-green-700 ring-green-300';
            $icon = '✅';
        }
    ?>

    <div class="space-y-6">

        
        <div class="flex flex-wrap items-center justify-between gap-4">

            <div>
                <h2 class="text-lg font-bold">
                    AI Financial Intelligence
                </h2>
                <p class="text-xs text-gray-500">
                    Decision & Growth Panel
                </p>
            </div>

            <div class="flex items-center gap-3">

                <span class="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-bold ring-1 <?php echo e($badge); ?>">
                    <?php echo e($icon); ?> <?php echo e($status); ?>

                </span>

                <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['size' => 'sm','wire:click' => 'generate','wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm','wire:click' => 'generate','wire:loading.attr' => 'disabled']); ?>
                    <span wire:loading.remove>Generate</span>
                    <span wire:loading>Thinking…</span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>

            </div>
        </div>

        
        <div class="rounded-xl bg-gradient-to-r from-primary-50 to-white p-4 border border-primary-100">
            <p class="text-xs font-semibold text-primary-700 uppercase mb-2">
                Overview
            </p>

            <div class="text-sm font-medium text-gray-800 leading-relaxed prose prose-sm max-w-none">
                <?php echo \Illuminate\Support\Str::markdown($trend); ?>

            </div>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">

            
            <div class="rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
                <p class="text-xs font-semibold text-primary-700 uppercase mb-3">
                    Risiko Utama
                </p>

                <div class="text-sm text-gray-700 leading-relaxed prose prose-sm max-w-none">
                    <?php echo \Illuminate\Support\Str::markdown($risk); ?>

                </div>
            </div>

            
            <div class="rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
                <p class="text-xs font-semibold text-primary-700 uppercase mb-3">
                    Aksi 7 Hari
                </p>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($action !== '-'): ?>
                    <ul class="text-sm text-gray-700 space-y-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = array_filter(explode(',', $action)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-start gap-2">
                                <span class="text-yellow-500 mt-0.5">☐</span>
                                <span class="prose prose-sm max-w-none">
                                    <?php echo \Illuminate\Support\Str::markdown(trim($item)); ?>

                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-sm text-gray-500">Belum ada rekomendasi</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div class="rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
                <p class="text-xs font-semibold text-primary-700 uppercase mb-3">
                    Peluang Strategis
                </p>

                <div class="text-sm text-gray-700 leading-relaxed prose prose-sm max-w-none">
                    <?php echo \Illuminate\Support\Str::markdown($opportunity); ?>

                </div>
            </div>

        </div>

        
        <div class="flex flex-wrap items-center justify-between gap-2 text-xs text-gray-400 pt-2 border-t border-gray-100">
            <span>
                AI-powered insights • Based on internal financial & sales data
            </span>
            <span>
                Last updated:
                <?php echo e(optional($report)->created_at?->format('d M Y H:i') ?? '-'); ?>

            </span>
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b945b32438afb742355861768089b04)): ?>
<?php $attributes = $__attributesOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__attributesOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b945b32438afb742355861768089b04)): ?>
<?php $component = $__componentOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__componentOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?><?php /**PATH /Users/macbook/Documents/ERP/App/resources/views/filament/widgets/financial-analyzer.blade.php ENDPATH**/ ?>